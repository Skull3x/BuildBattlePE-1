# BuildBattlePE
BuildBattle plugin!

# TODO
- [x] GameTask
- [ ] Voting  
- [x] World Reset
- [ ] Winner system
- [x] Particle System
